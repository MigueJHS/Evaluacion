import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import model.Odontologo;
import org.apache.log4j.Logger;

public class OdontologoDAOH2 {
    private Connection connection;

    public OdontologoDAOH2() {
        try {
            // Cargar el driver de H2 y establecer la conexión a la base de datos en memoria
            Class.forName("org.h2.Driver");
            connection = DriverManager.getConnection("jdbc:h2:mem:odontologos", "usuario", "contraseña");
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }

    public void guardarOdontologo(Odontologo odontologo) {
        String sql = "INSERT INTO odontologos (matricula, nombre, apellido) VALUES (?, ?, ?)";
        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setInt(1, odontologo.getMatricula());
            preparedStatement.setString(2, odontologo.getNombre());
            preparedStatement.setString(3, odontologo.getApellido());
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Odontologo> listarOdontologos() {
        List<Odontologo> odontologos = new ArrayList<>();
        String sql = "SELECT * FROM odontologos";
        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(sql)) {
            while (resultSet.next()) {
                Odontologo odontologo = new Odontologo();
                odontologo.setMatricula(resultSet.getInt("matricula"));
                odontologo.setNombre(resultSet.getString("nombre"));
                odontologo.setApellido(resultSet.getString("apellido"));
                odontologos.add(odontologo);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return odontologos;
    }
}