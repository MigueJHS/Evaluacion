package dao;
import java.util.ArrayList;
import java.util.List;
import model.Odontologo;
public class OdontologoDAOLista {
    private List<Odontologo> odontologos = new ArrayList<>();

    public void guardarOdontologo(Odontologo odontologo) {
        odontologos.add(odontologo);
    }

    public List<Odontologo> listarOdontologos() {
        return new ArrayList<>(odontologos);
    }
}